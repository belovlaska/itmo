public class Adult extends Human{

    public Adult(char sex, String role) {
        super(sex, role);
    }
}
