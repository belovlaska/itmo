public interface Abilities {

    void count(Item obj);

    void say(String str);
    void think(String str);
    void readBook(Book book);
    void painting();
    void shooting(PlasticGun gun, int times) throws SchoolShootingException;
    void feelEmotion(String str);
}
