public class BadBundlesCountExceptions extends RuntimeException{
    public BadBundlesCountExceptions() {
        super("Кто убил подарка?");
    }
}
