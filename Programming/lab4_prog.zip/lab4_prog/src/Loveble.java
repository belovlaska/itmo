public interface Loveble {
    default void love(){};
}
